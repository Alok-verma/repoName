import {GetServiceData} from '../../service/urlservice.js'
function getState(GetDataState){
    return{
            type:'GETDATA_STATE',
            GetDataState
    }
}
 export const GetDataAction=(pageNumber,pageRange,selectedOption,filterField,categoryName,shadeName)=>dispatch=>{
    let GetDataState = [];
    GetServiceData((data => {
            (data) ? GetDataState = data : console.log('error in fetching data')
        dispatch(getState(GetDataState))
    }),pageNumber,pageRange,selectedOption,filterField,categoryName,shadeName)
 }