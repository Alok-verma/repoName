import service from '../constant/services.js'
export function GetServiceData(actionCallback,pageNumber,pageRange,selectedOption,categoryName,shadeName) {
    var baseUrl=""
    if(selectedOption !==null){
          baseUrl=service.serviceUrl+pageNumber+':'+pageRange+"&sort="+selectedOption['value']+"%3"+selectedOption['orderBy']
    }else if(categoryName !==undefined  && categoryName !==null){
         baseUrl=service.serviceUrl+pageNumber+':'+pageRange+"&category="+categoryName[0]
    }else if(shadeName !==undefined &&shadeName !==undefined &&categoryName !==undefined && categoryName !==null){
        baseUrl=service.serviceUrl+pageNumber+':'+pageRange+"&category="+categoryName[0]+"&"+"filters-shade="+shadeName[0]+"&"
   }
    else{
          baseUrl=service.serviceUrl+pageNumber+':'+pageRange
    }
    fetch(baseUrl, {
        headers: new Headers({
            'Content-Type': 'application/json',
        })
    })
    .then(response => {
        if (response.status === 200 || response.status === 201 ) {
            response.json().then(json => actionCallback(json, "success"))
        } else {
            actionCallback([], "error")
        }
    })
}